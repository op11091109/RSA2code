1. The decimal range starts from 10 and enters 100 or less when entering the closed section (the time required increases exponentially if it exceeds 100)

2. Enter strings in English only

3. Built by Python 3.6 version